function About() {
    return (
      <div style={{ padding: '20px' }}>
        <h2>About This Project</h2>
       
      </div>
    );
  }
  
  export default About;