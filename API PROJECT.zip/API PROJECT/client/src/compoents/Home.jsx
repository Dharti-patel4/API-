function Home() {
    return (
      <div style={{ textAlign: 'center', marginTop: '40px' }}>
        <h1>Welcome to the Project!</h1>

         <h1>sign up and login page</h1>
      
      </div>
    );
  }
  
  export default Home;
  